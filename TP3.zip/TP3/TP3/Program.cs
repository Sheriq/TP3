﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP3
{
    class Program
    {
        static string[] docs = {
             "English tutorial and fast track",
            "learning latent semantic indexing",
            "Book on semantic indexing",
            "Advance in structure and semantic indexing",
            "Analysis of latent structures"
            };
        static List<string> querys;
        static List<string> terms = new List<string>();
        static int[][] matrix;
        static void Main(string[] args)
        {
            
             string[]q= {
                "latent AND NOT learning",                
                "Advance and structure AND NOT analysis",
                "learning OR Analysis AND latent",
                 "learning OR Analysis",
                //"structure or NOT Analysis",
                //"latent AND learning",
                //"English and not Semantic",
                //"Advance and structure AND analysis",

        };
            querys=q.ToList();

            foreach (string doc in docs)
            {
                var words = doc.Split(' ');
                foreach (string word in words)
                {
                    if (!terms.Contains(word) && word.Length > 3
                        //  && word != "and" && word != "or" && word !="in" && word!="not" && word != "on" && word !="of"
                        )
                        terms.Add(word);
                }
            }


            matrix = new int[terms.Count][];
            for (int i = 0; i < matrix.Length; i++)
                matrix[i] = new int[docs.Length];

            BuildMatrix();

            PrintMatrix();

            Retrivale();

            while (true)
            {
                querys = new List<string>();
                Print("Enter the query:");
                querys.Add(Read());
                Retrivale();

            }            
        }
        static List<Term> resultMatrix;
        static string[] queryMatrix;
        private static void Retrivale()
        {
            //for all queris
            for (int a = 0; a < querys.Count; a++)
            {
                resultMatrix = new List<Term>();
                queryMatrix = querys[a].ToLower().Split(' ');

                //1er boucle terms , not term:
                for (int i = 0; i < queryMatrix.Length; i++)
                    switch (queryMatrix[i])
                    {

                        case "not":
                            Term notterm = NOT(queryMatrix[i + 1]);
                            resultMatrix.Add(notterm);
                            i++;
                            break;

                        case "or":
                        case "and":
                            break;
                        default:
                            try
                            {
                                int[] matrixofTerm = MatrixOfTerm(queryMatrix[i]);

                                Term term = new Term(queryMatrix[i], matrixofTerm);
                                resultMatrix.Add(term);
                            }catch(Exception x) {
                                Print(x.Message);
                                return;
                            }
                            break;

                    }

                // 2 eme boucle or , and
                for (int i = 0; i < queryMatrix.Length; i++)
                    switch (queryMatrix[i])
                    {
                        case "or":
                            OR();

                            break;

                        case "and":
                            AND();
                            break;
                    }

                Console.WriteLine();
                Print(querys[a]);
                for (int i = 0; i < docs.Length; i++)
                    Console.Write("Doc" + (i + 1) + "\t");

                Console.WriteLine();
                //for (int i = 0; i < resultMatrix[a].Length; i++)
                {
                    Console.Write(resultMatrix[0]);
                }
                Console.WriteLine();
                Console.WriteLine();

               
            }
        }
        private static int[] MatrixOfTerm(string term)
        {

            for (int i = 0; i < terms.Count; i++)
            {
                if (terms[i].ToLower() == term)
                    return matrix[i];
            }
            throw new Exception("Term not Found");
            //return new int[docs.Length];


        }

        private static void BuildMatrix()
        {
            for (int i = 0; i < matrix.Length; i++)
            {
                for (int j = 0; j < docs.Length; j++)
                {
                    if (docs[j].Contains(terms[i]))
                    {
                        matrix[i][j] = 1;
                    }
                }
            }
        }

        static void PrintMatrix()
        {
            Print(terms.Count + " terms founds");
            Print("Terme-document matrix:");
            Console.Write("Term\t\t");
            for (int i = 0; i < docs.Length; i++)
                Console.Write("Doc" + (i + 1) + "\t");

            Console.WriteLine();

            string line;
            for (int i = 0; i < terms.Count; i++)
            {
                line = terms[i] + "\t";
                if (line.Length <= 8)
                    line += "\t";

                for (int j = 0; j < matrix[0].Length; j++)
                    line += matrix[i][j] + "\t";

                Console.WriteLine(line);
            }
        }


        static void Print(object s)
        {
            Console.WriteLine(s);
        }
        static string Read()
        {
            return Console.ReadLine();
        }

        static void AND()
        {
            int[] res = AND(resultMatrix[0].matrix, resultMatrix[1].matrix);

            string termstr = resultMatrix[0].termstr + " AND " + resultMatrix[1].termstr;
            // resultMatrix.Add(new Term(termstr, res));

            resultMatrix[0] = new Term(termstr, res);


            resultMatrix.RemoveAt(1);


        }
        static void OR()
        {
            int[] res = OR(resultMatrix[0].matrix, resultMatrix[1].matrix);

            string termstr = resultMatrix[0].termstr + " OR " + resultMatrix[1].termstr;

            resultMatrix[0] = new Term(termstr, res);

            resultMatrix.RemoveAt(1);


        }
        static int[] AND(int[] a, int[] b)
        {
            int[] c = new int[docs.Length];

            for (int i = 0; i < docs.Length; i++)
            {
                c[i] = a[i] * b[i];
            }
            return c;

        }
        static int[] OR(int[] a, int[] b)
        {
            int[] c = new int[docs.Length];

            for (int i = 0; i < docs.Length; i++)
            {
                if (a[i] + b[i] >= 1)
                    c[i] = 1;
            }
            return c;

        }
        static Term NOT(string termstr)
        {

            int[] notMatrix = new int[docs.Length];
            for (int i = 0; i < terms.Count; i++)
            {
                if (termstr == terms[i].ToLower())
                {
                    notMatrix = matrix[i];
                    for (int j = 0; j < notMatrix.Length; j++)
                    {
                        if (notMatrix[j] == 0)
                            notMatrix[j] = 1;
                        else notMatrix[j] = 0;

                    }
                    Term tterm = new Term("not" + termstr, notMatrix);
                    return tterm;

                }
            }

            //return null;
            throw new Exception("Term not Found");
        }
    }
}
