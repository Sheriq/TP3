﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP3
{
    class Term
    {
        
        
         public int[] matrix;
        public string termstr;

        public Term(string termstr, int[] notMatrix)
        {
            this.termstr = termstr;
            this.matrix = notMatrix;
        }

        public override string ToString()
        {
            string s = "";

            foreach (int i in matrix)
                s += i + "\t";

            return s;

        }
    }
}
